Building and installing the MinIISC application
================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.
